<?php 
Class WeeklyReportsContr extends WeeklyReports{
    public function insertNewWeek($count, $studentid, $groupid){
        return $this->insertWeek($count, $studentid, $groupid);   
    }
    public function updatestudentReport($submitted, $status, $week, $studentid){
        return $this->studentReport($submitted, $status, $week, $studentid);   
    }
    public function updateInsertEval($evaluation, $weekid){
        return $this->updateInsertWeek($evaluation, $weekid);   
    }
    public function insertgroupReport($groupid, $week){
        return $this->groupReport($groupid, $week);   
    }
}