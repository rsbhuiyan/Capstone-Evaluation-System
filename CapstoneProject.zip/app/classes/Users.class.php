<?php
class Users extends Dbh
{

    protected function emailInDB($email)
    {
        $sql = "SELECT email from users where email = ? and activeUser = '1';";
        $query1 = $this->connect()->prepare($sql);
        $query1->execute([$email]);
        if ($query1->rowCount() == 0) {
            return false;
        }
        if ($query1->rowCount() > 0) {
            return true;
        }
    }

    protected function isPasswordSet($email)
    {
        $sql = "SELECT email from users where email = ?;";
        $query = $this->connect()->prepare($sql);
        $query->execute([$email]);
        if ($query->rowCount() > 0) {
            $sql1 = "SELECT pass from users where email = ?;";
            $query1 = $this->connect()->prepare($sql1);
            $query1->execute([$email]);
            if ($query1->rowCount() > 0) {
                while ($row1 = $query1->fetch()) {
                    if (!is_null($row1['pass'])) {
                        return true;
                    }
                }
            }
            return false;
        }
    }
    protected function getPassword($email)
    {
        $sql = "SELECT pass from users where email = ?;";
        $query = $this->connect()->prepare($sql);
        $query->execute([$email]);
        if ($query->rowCount() > 0) {
            $row1 = $query->fetch();
            $results = $row1['pass'];
            return $results;
        }
        return null;
    }
    protected function getroleofUser($email)
    {
        $sql = "SELECT roleofuser from users where email = ? ;";
        $query = $this->connect()->prepare($sql);
        $query->execute([$email]);
        if ($query->rowCount() > 0) {
            $row1 = $query->fetch();
            $results = $row1['roleofuser'];
            return $results;
        }
        return null;
    }
    protected function doesUserEmailExists($email)
    {
        $sql = "SELECT email from users where email = ?;";
        $query = $this->connect()->prepare($sql);
        $query->execute([$email]);
        if ($query->rowCount() > 0) {
            return true;
        }
        return false;
    }
    protected function insertAdmin($firstname, $lastname, $email)
    {
        $sql = "INSERT INTO users (firstname, lastname, email, roleofuser) VALUES ( ?, ?, ?,  'admin');";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute([$firstname, $lastname, $email]);
        return $result;
    }
    protected function insertGTA($firstname, $lastname, $email)
    {
        $sql = "INSERT INTO users (firstname, lastname, email, roleofuser) VALUES ( ?, ?, ?,  'GTA');";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute([$firstname, $lastname, $email]);
        return $result;
    }
    protected function selectAdmin($email)
    {
        $sql = "SELECT * FROM users where roleofuser = 'admin';";
        $query = $this->connect()->prepare($sql);
        $query->execute();
        if ($query->rowCount() > 0) {
            $row1 = $query->fetchAll();
        }
        return $row1;
    }

    protected function selectProfessor()
    {
        $sql = "SELECT * from users where roleofuser = 'professor' AND activeUser = '1';";
        $query = $this->connect()->prepare($sql);
        $query->execute();
        if ($query->rowCount() > 0) {
            $row1 = $query->fetchAll();
            return $row1;
        }

    }
    protected function selectUserByID($userid)
    {
        $row1 = null;
        $sql = "SELECT * from users where userid = ?;";
        $query = $this->connect()->prepare($sql);
        $query->execute([$userid]);
        if ($query->rowCount() > 0) {
            $row1 = $query->fetchAll();
        }
        return $row1;
    }
    protected function selectUserInfo($email)
    {
        $row1 = null;
        $sql = "SELECT * from users where email = ?;";
        $query = $this->connect()->prepare($sql);
        $query->execute([$email]);
        if ($query->rowCount() > 0) {
            $row1 = $query->fetchAll();
        }
        return $row1;
    }
    protected function selectGta()
    {
        $row1 = null;
        $sql = "SELECT * from users where roleofuser = 'GTA' and activeuser = '1';";
        $query = $this->connect()->prepare($sql);
        $query->execute();
        if ($query->rowCount() > 0) {
            $row1 = $query->fetchAll();
        }
        return $row1;
    }
    protected function selectOneProf($email)
    {
        $sql = "SELECT userid FROM users WHERE email = '$email';";
        $query = $this->connect()->prepare($sql);
        $query->execute();
        if ($query->rowCount() > 0) {
            $row1 = $query->fetch();
            return $row1;
        }
        return null;
    }
    protected function selectProfNameFromSec($section_name)
    {
        $sql = "SELECT userid, firstname, lastname from users u join section sc on u.userid = sc.professor join semester se on se.semesterid = sc.semesterid where sc.section_name =?;";
        $query = $this->connect()->prepare($sql);
        $query->execute([$section_name]);
        if ($query->rowCount() > 0) {
            $row1 = $query->fetchAll();
        }
        return $row1;
    }
    protected function updateEmail($email)
    {
        $sql = "UPDATE users SET email=? WHERE email = ?;";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$email, $email]);
    }

    protected function editProfessor($userid, $firstname, $lastname, $email)
    {
        $sql = "UPDATE users SET firstname=?, lastname=?, email=? WHERE userid = ?;";
        $stmt = $this->connect()->prepare($sql);
        $stmt = $stmt->execute([$firstname, $lastname, $email, $userid]);

    }
    protected function updateActiveUser($userid)
    {
        $sql = "UPDATE users SET activeUser = '0' WHERE userid = ?;";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$userid]);

    }

    protected function getActiveGTA()
    {
        $sql = "SELECT * from users where roleofuser = 'GTA' AND activeUser = '1';";
        $query = $this->connect()->prepare($sql);
        $query->execute();
        if ($query->rowCount() > 0) {
            $row1 = $query->fetchAll();
            return $row1;
        }
    }
    //Shows edit GTA in view
    protected function editGTA($userid, $firstname, $lastname, $email)
    {
        $sql = "UPDATE users SET firstname=?, lastname=?, email=? WHERE userid = ?;";
        $stmt = $this->connect()->prepare($sql);
        $stmt = $stmt->execute([$firstname, $lastname, $email, $userid]);

    }

    protected function addPreviousUser($userid)
    {
        $sql = "UPDATE users SET activeUser = '1' WHERE userid = ?;";
        $stmt = $this->connect()->prepare($sql);
        $stmt->execute([$userid]);

    }

    protected function selectDeactivatedProfessor()
    {
        $sql = "SELECT * from users where roleofuser = 'professor' AND activeUser = '0';";
        $query = $this->connect()->prepare($sql);
        $query->execute();
        if ($query->rowCount() > 0) {
            $row1 = $query->fetchAll();
            return $row1;
        }
    }

    protected function inactiveGTA()
    {
        $row1 = null;
        $sql = "SELECT * from users where roleofuser = 'GTA' and activeuser = '0';";
        $query = $this->connect()->prepare($sql);
        $query->execute();
        if ($query->rowCount() > 0) {
            $row1 = $query->fetchAll();
        }
        return $row1;
    }
    protected function getGtaProf($userid){
        $row1 = null;
        $sql ="SELECT DISTINCT gtaAssignment.gta, users.firstname, users.lastname FROM gtaAssignment JOIN users ON users.userid = gtaAssignment.gta WHERE gtaAssignment.sectionid IN ( SELECT sectionid FROM section WHERE professor = $userid );";
        $query = $this->connect()->prepare($sql);
        $query->execute();
        if ($query ->rowCount() > 0){
            $row1 = $query->fetchAll();
        }
        return $row1;
    }
 
}
?>