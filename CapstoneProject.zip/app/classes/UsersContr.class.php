<?php
class UsersContr extends Users{
   
    public function insertUserAdmin($firstname, $lastname, $email){
        return $this->insertAdmin($firstname, $lastname, $email);   
    }
    public function professorEdit($userid, $firstname, $lastname, $email){
        return $this->editProfessor($userid, $firstname, $lastname, $email);
    }

    public function insertUserGta($firstname, $lastname, $email){
        return $this->insertGTA($firstname, $lastname, $email);   
    }
     //Changes GTA and professor 'activeuser' status in the database from 1 to 0.
    public function activeUser($userid){
        return $this->updateActiveUser($userid);
    }
    //Shows edit GTA in view
    //editGTA is in Users.class
    public function gtaEdit($userid, $firstname, $lastname, $email){
        return $this->editGTA($userid, $firstname, $lastname, $email);

    }

 //Changes GTA and professor 'activeuser' status in the database from 0 to 1.
    public function reactivateUser($userid){
        return $this->addPreviousUser($userid);
    }
}
?>