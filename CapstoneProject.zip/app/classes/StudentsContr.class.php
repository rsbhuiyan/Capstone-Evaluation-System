<?php 
Class StudentsContr extends Students{
    public function insertUserStudent($accessid, $name, $selectSection, $activeStudent){
        return $this->insertStudent($accessid, $name, $selectSection, $activeStudent);   
    }

    public function updateGroup($student, $groups){
        return $this->updateGroupid($student, $groups);   
    }

    public function removeGroup($studentid){
        return $this->removeGroupid($studentid);   
    }

    public function deleteStudent($student){
        return $this->studentDelete($student);   
    }

    public function reAddStudent($inactiveStudent){
        return $this->reAddInactiveStudent($inactiveStudent);   
    }

    
}
