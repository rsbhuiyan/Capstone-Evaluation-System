<?php
class Students extends Dbh
{
    protected function selectStudentFromGroup($sectionid, $groupid)
    {
        $row1 = null;
        $sql = "SELECT studentid, name from students where sectionid = ? and groupid = ?;";
        $query = $this->connect()->prepare($sql);
        $query->execute([$sectionid, $groupid]);
        if ($query->rowCount() > 0) {
            $row1 = $query->fetchAll();
        }
        return $row1;
    }
    protected function selectallStuInfo($studentid)
    {
        $row1 = null;
        $sql = "SELECT s.*, gt.groupName from students s
        join groupTable gt on gt.groupid = s.groupid
        where s.studentid = ?;";
        $query = $this->connect()->prepare($sql);
        $query->execute([$studentid]);
        if ($query->rowCount() > 0) {
            $row1 = $query->fetch();
        }
        return $row1;
    }
    protected function selectStudentGroup($groupid)
    {
        $row1 = null;
        $sql = "SELECT studentid, name from students where groupid = ?;";
        $query = $this->connect()->prepare($sql);
        $query->execute([$groupid]);
        if ($query->rowCount() > 0) {
            $row1 = $query->fetchAll();
        }
        return $row1;
    }
    protected function selectGroupidfromStu($studentid)
    {
        $row1 = null;
        $sql = "SELECT groupid from students where studentid = ?;";
        $query = $this->connect()->prepare($sql);
        $query->execute([$studentid]);
        if ($query->rowCount() > 0) {
            $row1 = $query->fetch();
        }
        return $row1;
    }
    protected function insertStudent($accessid, $name, $selectSection, $activeStudent)
    {
        $sql = "INSERT INTO students (accessID, name, sectionid, activeStudent) VALUES (?, ?, ?, ?)";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute([$accessid, $name, $selectSection, $activeStudent]);
        return $result;
    }


    protected function doesAccessidExists($accessid){
        $sql ="SELECT accessID FROM students WHERE accessID = ? AND activeStudent = 1;";

        $query = $this->connect()->prepare($sql);
        $query->execute([$accessid]);
        if ($query->rowCount() > 0) {
            return true;
        }
        return false;
    }


   //returns students not in a group
   protected function studentsNoGroup($section){
        $sql ="SELECT * from alphabetical where sectionid = ? AND activeStudent = 1;";
        $query = $this->connect()->prepare($sql);
        $query->execute([$section]);
        if ($query->rowCount() > 0) {
            $row1 = $query->fetchAll();
            return $row1;
        } else {
            return "There are no students in this section.";
        }
    }


    protected function selectStudent($studentid)
    {
        $sql = "SELECT name from students WHERE studentid = ?;";
        $result = $this->query($sql, [$studentid]);
        if ($result) {
            return $result[0];
        }
        return false;

    }
    protected function studentName($studentid)
    {
        $sql = "SELECT name from students WHERE studentid = ?;";
        $query = $this->connect()->prepare($sql);
        $query->execute([$studentid]);
        if ($query->rowCount() > 0) {
            return $query->fetch();
        }

    }
    protected function selectStudentAll($gtaid)
    {
        $sql = "SELECT DISTINCTs.studentid, name from students s  inner join groupTable g on g.groupid = s.groupid inner join gtaassignment ga on g.groupid = ga.groupid where ga.gta = ?;";
        $query = $this->connect()->prepare($sql);
        $query->execute([$gtaid]);
        if ($query->rowCount() > 0) {
            return $query->fetchAll();
        }
    }

    protected function updateGroupid($student, $groups)
    {
        $sql = "UPDATE students SET groupid = ? WHERE studentid = ?;";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute([$groups, $student]);
        return $result;
    }

    protected function removeGroupid($studentid)
    {
        $sql = "UPDATE students SET groupid = NULL WHERE studentid = ?;";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute([$studentid]);
        return $result;
    }

    protected function studentDelete($student){
        $sql = "UPDATE students SET  activeStudent = 0 WHERE studentid = ?;";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute([$student]);
        return $result;
    }

   
   protected function selectStudentsInactive($section){
        $sql ="SELECT * from alphabetical where sectionid = ? AND activeStudent = 0;";
        $query = $this->connect()->prepare($sql);
        $query->execute([$section]);
        if ($query ->rowCount() > 0){
            $row1 = $query->fetchAll();
            return $row1;
        }
        else {
            return "There are no students in this section.";
        }
    }

    protected function reAddInactiveStudent($inactiveStudent){
        $sql = "UPDATE students SET  activeStudent = 1 WHERE studentid = ?;";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute([$inactiveStudent]);
        return $result;
    }

}

