<?php 
Class WeeklyReportsView extends WeeklyReports{
    public function getWeeks($groupid){
        $results = $this->selectWeeks($groupid);
        return $results;
    }
    public function numberOfWeeks(){
        $results = $this->numWeeks();
        return $results;
    }
    public function reportByWeekId($week, $studentid){
        $results = $this->selectWeekbyid($week, $studentid);
        return $results;
    }
    public function reportGroupByWeek($week){
        $results = $this->selectGroupByWeek($week);
        return $results;
    }
    public function isReportSubmitted($week, $studentid){
        $results = $this->isSubmitted($week, $studentid);
        return $results;
    }
    public function isGroupReportSubmitted($week, $groupid){
        $results = $this->isGroupSubmitted($week, $groupid);
        return $results;
    }
    public function weekID($week, $studentid){
        $results = $this->selectWeekID($week, $studentid);
        return $results;
    }
    public function WeekIDfromEval($weekid){
        $results = $this->selectWeekIDfromEval($weekid);
        return $results;
    }
    public function countWeeksforStudent($week, $studentid){
        $results = $this->countWeeks($week, $studentid);
        return $results;
    }
    public function getAllWeeklyReportData($studentid){
        $results = $this->selectAllWeeklyReportData($studentid);
        return $results;
    }
    public function countSubmittedValues($studentid){
        $results = $this->selectSubmittedValues($studentid);
        return $results;
    }
    public function countStatusValues($studentid){
        $results = $this->selectStatusValues($studentid);
        return $results;
    }
    
   
}