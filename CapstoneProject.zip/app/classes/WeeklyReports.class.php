<?php 
Class WeeklyReports extends Dbh{
    protected function insertWeek($count, $studentid, $groupid){
        $sql = "INSERT INTO weeklyReports (week, studentid, groupid) VALUES ( ?, ?, ?);";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute([$count, $studentid, $groupid]);
        return $result;
    }

    protected function numWeeks(){
        $row1 = null;
            $sql ="SELECT ROUND(DATEDIFF(endDate, startDate)/7, 0) AS weeksout from semester where endDate > CURRENT_DATE() and startDate < current_date();";
            $query = $this->connect()->prepare($sql);
            $query->execute([]);
            if ($query ->rowCount() > 0){
                $row1 = $query->fetchAll();
            }
            return $row1;
    }
    protected function selectWeeks($groupid){
            $row1 = null;
            $sql ="SELECT * from weeklyReports where groupid = ?";
            $query = $this->connect()->prepare($sql);
            $query->execute([$groupid]);
            if ($query ->rowCount() > 0){
                $row1 = $query->fetchAll();
            }
            return $row1;
    }
   
    protected function studentReport($submitted, $status, $week, $studentid){
        $sql = "UPDATE weeklyReports SET dateSubmitted = CURRENT_DATE(), submitted=?, status=?  WHERE week = ? and studentid = ?;";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute([$submitted, $status, $week, $studentid]);
        return $result;
    }

    protected function groupReport($groupid, $week){
        $sql = "INSERT INTO weeklyReports (dateSubmitted, groupid, week, studentid) VALUES(CURRENT_DATE(), ?, ?, -1)";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute([$groupid, $week]);
        return $result;
    }
    protected function selectWeekbyid($week, $studentid){
        $row1 = null;
        $sql ="SELECT wr.*, wre.evaluation, s.name from weeklyReports wr
        join weeklyReportsEval wre on wr.weekid = wre.weekid
        join students s on s.studentid = wr.studentid
        where wr.week = ? AND wr.studentid = ?;";
        $query = $this->connect()->prepare($sql);
        $query->execute([$week, $studentid]);
        if ($query ->rowCount() > 0){
            $row1 = $query->fetchAll();
        }
        return $row1; 
}
protected function selectGroupByWeek($week){
    $row1 = null;
    $sql ="SELECT wr.*, wre.evaluation, gt.groupName from weeklyReports wr
    join weeklyReportsEval wre on wr.weekid = wre.weekid
    join groupTable gt on gt.groupid = wr.groupid
    where wr.week = ? AND wr.studentid = -1;";
    $query = $this->connect()->prepare($sql);
    $query->execute([$week]);
    if ($query ->rowCount() > 0){
        $row1 = $query->fetchAll();
    }
    return $row1; 
}
protected function isSubmitted($week, $studentid){
    $row1 = null;
    $sql ="SELECT submitted, status from weeklyReports where week = ? AND studentid = ?";
    $query = $this->connect()->prepare($sql);
    $query->execute([$week, $studentid]);
    if ($query ->rowCount() > 0){
        $row1 = $query->fetchAll();
    }
    return $row1;
}
protected function isGroupSubmitted($week, $groupid){
    $row1 = null;
    $sql ="SELECT wre.evaluation from weeklyReportsEval wre join weeklyReports wr on wr.weekid = wre.weekid where week = ? AND studentid = -1 and groupid = ?;";
    $query = $this->connect()->prepare($sql);
    $query->execute([$week, $groupid]);
    if ($query ->rowCount() > 0){
        $row1 = $query->fetchAll();
    }
    return $row1;
}
protected function selectWeekID($week, $studentid){
    $row1 = null;
    $sql ="SELECT weekid from weeklyReports where week = ? AND studentid = ?";
    $query = $this->connect()->prepare($sql);
    $query->execute([$week, $studentid]);
    if ($query ->rowCount() > 0){
        $row1 = $query->fetchAll();
    }
    return $row1;
}

protected function updateInsertWeek($evaluation, $weekid){
    $sql = "SELECT count(*) FROM weeklyReportsEval WHERE weekid = ?";
    $query = $this->connect()->prepare($sql);
    $query->execute([$weekid]);
    $row = $query->fetch();
    $count = $row["count(*)"];
  
    if ($count == 0) {
        $sql = "INSERT INTO weeklyReportsEval (evaluation, weekid) VALUES ( ?, ?);";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute([$evaluation, $weekid]);
    } else {
        $sql = "UPDATE weeklyReportsEval SET evaluation = ? WHERE weekid = ? ;";
        $stmt = $this->connect()->prepare($sql);
        $result = $stmt->execute([$evaluation, $weekid]);
    }
    return $result;
}

protected function selectWeekIDfromEval($weekid){
    $row1 = null;
    $sql ="SELECT * from weeklyReportsEval where weekid ?;";
    $query = $this->connect()->prepare($sql);
    $query->execute([$weekid]);
    if ($query->rowCount() > 0){
        $row1 = $query->fetchAll();
    }
    return $row1;

}
protected function countWeeks($week, $studentid){
    $row1 = null;
    $sql ="SELECT count(1) FROM weeklyReports WHERE week = ? and studentid = ?;";
    $query = $this->connect()->prepare($sql);
    $query->execute([$week, $studentid]);
    if ($query->rowCount() > 0){
        $row1 = $query->fetch();
    }
    return $row1;
}
protected function selectAllWeeklyReportData($studentid){
    $row1 = null;
    $sql ="SELECT wr.*, wre.evaluation from weeklyReports wr
    join weeklyReportsEval wre on wr.weekid = wre.weekid
    where studentid = ? or studentid = -1";
    $query = $this->connect()->prepare($sql);
    $query->execute([$studentid]);
    if ($query ->rowCount() > 0){
        $row1 = $query->fetchAll();
    }
    return $row1;
}

protected function selectSubmittedValues($studentid){
$row1 = null;
$sql ='SELECT SUM(qty), submitted FROM (
    SELECT COUNT(0) AS qty, submitted FROM weeklyReports WHERE studentid = ? AND submitted
    IN ("on time","late submission", "no submission", "revoked") GROUP BY submitted
    UNION 
    SELECT 0 AS qty, "on time" AS submitted 
    UNION 
     SELECT 0 AS qty, "late submission" AS submitted
     UNION 
    SELECT 0 AS qty, "no submission" AS submitted
    UNION 
     SELECT 0 AS qty, "revoked" AS submitted
) t
GROUP BY submitted;';
$query = $this->connect()->prepare($sql);
$query->execute([$studentid]);
if ($query ->rowCount() > 0){
    $row1 = $query->fetchAll();
}
return $row1;
}
protected function selectStatusValues($studentid){
    $row1 = null;
    $sql ='SELECT SUM(qty), status FROM (
        SELECT COUNT(0) AS qty, status FROM weeklyReports WHERE studentid = ? AND status
        IN ("advanced","good", "achieved", "behind") GROUP BY status
        UNION 
        SELECT 0 AS qty, "advanced" AS status 
        UNION 
         SELECT 0 AS qty, "good" AS status
         UNION 
        SELECT 0 AS qty, "achieved" AS status
        UNION 
         SELECT 0 AS qty, "behind" AS status
    ) t
    GROUP BY status ;';
    $query = $this->connect()->prepare($sql);
    $query->execute([$studentid]);
    if ($query ->rowCount() > 0){
        $row1 = $query->fetchAll();
    }
    return $row1;
    }
}