<?php 
Class StudentsView extends Students{
    public function studentFromGroup($sectionid, $groupid){
        $results = $this->selectStudentFromGroup($sectionid, $groupid);
        return $results;
    }
    public function studentGroup($groupid){
        $results = $this->selectStudentGroup($groupid);
        return $results;
    }
    public function userAccessid($accessid){
        $results = $this->doesAccessidExists($accessid);
        return $results;
    }

    //gets students that arent in a group
    public function selectStudentsNoGroup($section){
        $results = $this->studentsNoGroup($section);
        return $results;
    }
    public function selectallStudentInfo($studentid){
        $results = $this->selectallStuInfo($studentid);
        return $results;
    }
    public function studentInfo($studentid){
        $results = $this->selectStudent($studentid);
        return $results ? [$results] : false; 
    }
    public function selectGroupidfromStudent($studentid){
        $results = $this->selectGroupidfromStu($studentid);
        return $results;
    }
   
    public function studentInfoAll($gtaid){
        $results = $this->selectStudentAll($gtaid);
        return $results;
    }
    public function selectstudentName($studentid){
        $results = $this->studentName($studentid);
        return $results;
    }

    public function selectInactiveStudents($section){
        $results = $this->selectStudentsInactive($section);
        return $results;
    }

   
}
