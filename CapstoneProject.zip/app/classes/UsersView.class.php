<?php
class UsersView extends Users{
    public function emailCheck($email){
        $results = $this->emailInDB($email);
        return $results;
    }
    public function passwordSet($email){
        $results = $this->isPasswordSet($email);
        return $results;
    }
    public function getthePassword($email){
        $results = $this->getPassword($email);
        return $results;
    }
    public function gettheRole($email){
        $results = $this->getroleofUser($email);
        return $results;
    }
    public function selectTheOneProf($email){
        $results = $this->selectOneProf($email);
        return $results;
    }
    public function userEmail($email){
        $results = $this->doesUserEmailExists($email);
        return $results;
    }
    public function adminInfo($email){
        $results = $this->selectAdmin($email);
        return $results;
    }
    public function professorInfo(){
        $results = $this->selectProfessor();
        return $results;
    }
    public function gtaInfo(){
        $results = $this->selectGta();
        return $results;
    }
    public function selectProfFromSec($section_name){
        $results = $this->selectProfNameFromSec($section_name);
        return $results;
    }
    public function allUserInfo($email){
        $results = $this->selectUserInfo($email);
        return $results;
    }
    public function userInfoByID($userid){
        $results = $this->selectUserByID($userid);
        return $results;
    }
    public function getProfGtas($userid){
        $results = $this->getGtaProf($userid);
        return $results;
    }
    //Get the info for active GTAs to be displayed in the profDashAddGta file
    //only displays GTA's where Active user = 1
   
    //public function selectProfs(){
      //  $results = $this->selectProf();
       // return $results;
    //}
            
    public function professorInfoDeactive(){
        $results = $this->selectDeactivatedProfessor();
        return $results;
    }

    
    public function isGtaActivate(){
        $results = $this->inactiveGTA();
        return $results;
    }
  
}


